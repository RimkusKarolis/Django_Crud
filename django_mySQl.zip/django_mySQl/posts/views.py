from django.shortcuts import render, redirect
from .models import Post

# Create your views here.
def list_posts(request):
    posts = Post.objects.all()
    return render(request, "main.html", {"posts": posts})


def create_post(request):
    new_fullName = request.POST["fullName"]
    new_date = request.POST["date"]
    new_fullUrl = request.POST["fullUrl"]
    new_comment = request.POST['comment']

    if new_fullName == "" or new_date == "" or new_fullUrl =="" or new_comment == "":
        posts = Post.objects.all()
        return render(
            request, "main.html", {"post": posts, "error": "fields are required"}
        )
    post = Post(fullName=new_fullName, date=new_date, fullUrl=new_fullUrl, comment=new_comment)
    post.save()
    return redirect("/posts/")


def delete_post(request, post_id):
    post = Post.objects.get(id=post_id)
    post.delete()
    return redirect("/posts/")

def update_post(request):
    fullName = request.POST["fullName"]
    date = request.POST["date"]
    fullUrl = request.POST["fullUrl"]
    comment = request.POST['comment']

    update = Post.objects.get(id=id)
    update.fullName = fullName
    update.date = date
    update.fullUrl = fullUrl
    update.comment = comment
    update.save()

    return redirect('/posts')
